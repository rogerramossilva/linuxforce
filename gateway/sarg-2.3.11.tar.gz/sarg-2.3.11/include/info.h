#define VERSION PACKAGE_VERSION" Jan-14-2018"
#define PGM PACKAGE_NAME
#define URL "http://sarg.sourceforge.net"
