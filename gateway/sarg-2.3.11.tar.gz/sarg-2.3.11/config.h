/*
Stub file that should be used when the program is not configured by cmake. If you use
cmake to configure sarg, a config.h file will be created in ${CMAKE_BINARY_DIR} and should
be used before this one.
*/
